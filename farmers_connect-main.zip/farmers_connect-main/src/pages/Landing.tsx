import LandingPage from "@/components/LandingPage";

const Landing = () => {
  return <LandingPage />;
};

export default Landing;




